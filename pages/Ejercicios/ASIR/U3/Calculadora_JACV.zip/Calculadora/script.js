var inp = 0;
var v1 = 0;
var v2 = 0;
var res = 1;
var i = 1;


while (inp != 7){
    inp = parseInt(prompt("Introduce una opción: \n1 - Suma\n2 - Resta\n3 - División\n4 - Multiplicación\n5 - Potencia\n6 - Factorial\n7 - Salir"));
    switch(inp){
        //SUMA
        case 1:
            v1 = parseFloat(prompt("Introduce el primer número:"));
            v2 = parseFloat(prompt("Introduce el segundo número:"));

            if(isNaN(v1) || isNaN(v2)){
                alert("Tipo de dato no válido");
            }
            else{
                res = v1+v2;
                alert("El resultado es " + res);
            }

            break;
        //RESTA
        case 2:
            v1 = parseFloat(prompt("Introduce el primer número:"));
            v2 = parseFloat(prompt("Introduce el segundo número:"));

            if(isNaN(v1) || isNaN(v2)){
                alert("Tipo de dato no válido");
            }
            else{
            res = v1-v2;
            alert("El resultado es " + res);
            }

            break;
        //DIVISION
        case 3:
            v1 = parseFloat(prompt("Introduce el dividendo:"));
            v2 = parseFloat(prompt("Introduce el divisor(no puede ser 0)"));


            if(isNaN(v1) || isNaN(v2)){
                alert("Tipo de dato no válido");
            }
            else{
                if (v2 != 0){
                    res = v1/v2;
                    alert("El resultado es " + res);
                }
                else{
                    alert("El divisor no puede ser 0");
                }
            }

            break;
        //MULTIPLICACION
        case 4:
            v1 = parseFloat(prompt("Introduce el primer número:"));
            v2 = parseFloat(prompt("Introduce el segundo número:"));

            if(isNaN(v1) || isNaN(v2)){
                alert("Tipo de dato no válido");
            }
            else{
                res = v1*v2;
                alert("El resultado es " + res);
            }

            break;
        //POTENCIA
        case 5:
            v1 = parseFloat(prompt("Introduce la base:"));
            v2 = parseFloat(prompt("Introduce el exponente:"));

            if(isNaN(v1) || isNaN(v2)){
                alert("Tipo de dato no válido");
            }
            else{
                res = v1**v2;
                alert("El resultado es " + res);
            }

            break;
        //FACTORIAL
        case 6:
            v1 = parseFloat(prompt("Introduce un número"));
            res = 1;

            if(isNaN(v1)){
                alert("Tipo de dato no válido");
            }
            else{
                for (i = v1; i > 1; i--){
                    res = res*i;
                    console.log(res)
                }
                alert("El resultado es " + res);
            }

            break;
    }
}
