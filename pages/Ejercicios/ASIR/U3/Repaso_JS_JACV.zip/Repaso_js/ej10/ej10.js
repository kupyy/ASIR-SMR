var n = parseInt(prompt("Introduce un número"));
var i = 1;
var x = 0;

for (i; i<=n; i++){
    x = x+i;
}

document.write("El resultado es " + x);