var ar1 = [1,2,3,4,5];
var ar2 = ar1.reverse();
//ar2.reverse();

document.write(ar1);
document.write("<br>");
document.write(ar2);