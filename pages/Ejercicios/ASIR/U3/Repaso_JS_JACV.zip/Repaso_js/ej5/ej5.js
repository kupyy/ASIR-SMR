var n = parseInt(prompt("Dime un número"));

for (var i = 0; i <= n; n--){
    if(n == 0){
        document.write(n);
    }
    else{
        document.write(n + ", ");
    }
}