/*Mensaje que se muestra al abrir la página*/
alert("Hola Mundo!");

/*Segundo mensaje*/ 
alert("Este es mi primer script");

/*Este comando hace que al pulsar el botón muestre un mensaje
*/document.getElementById('hi').addEventListener("click", function() {alert("Hola de nuevo!");});